# Vue.js 2
## Editor HTML básico con la directiva v-html

Uso de la directiva v-html para renderizar texto en
formato HTML, en vez de plano.

- Directiva v-html
- Modelos
