# Ejemplos de Vue.js 2
En este repositorio encontrará ejemplos en los que se utiliza el framework Vue.js 2. 
Cada ejemplo cuenta con una breve descripción. Todo el código de este repositorio puede ser de ayuda para principiantes y/o personas que apenas se inician en Vue.js 2.
Este fork ha sido mejorado  incluyendo mayor detalle en los comentarios respecto al fork original (https://github.com/calirojas/vuejs2).
#Principales novedades

1) Se ha añadido un proyecto básico de iniciación llamado "Hello World".
2) El proyecto "lista-de-tareas" ahora incorpora persistencia local usando "LocalStorage".
3) Se ha añadido un proyecto Cordova con el programa "lista-de-tareas". Dicho Ejemplo esta en el proyecto "lista-de-tareas-cordova" y permite ser desplegado sin problemas en Android e IOS, sin necesidad de conexión a Internet. Se incluye "APK" generado.
