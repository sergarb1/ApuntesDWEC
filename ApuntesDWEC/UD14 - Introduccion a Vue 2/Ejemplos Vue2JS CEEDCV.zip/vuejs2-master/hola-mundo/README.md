# Vue.js 2
## hola mundo

Mi primer programa con Vue.
Se muestra "Hola mundo" y permite invertir la cadena.
