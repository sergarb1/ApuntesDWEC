# Vue.js 2
## Interpolación de atributos con v-bind

Interpolación de atributos haciendo uso de la directiva
v-bind.

Se incluye el uso de:
- Directiva v-bind
- Modelos
- Expresiones
- Directiva v-on
- Interpolación