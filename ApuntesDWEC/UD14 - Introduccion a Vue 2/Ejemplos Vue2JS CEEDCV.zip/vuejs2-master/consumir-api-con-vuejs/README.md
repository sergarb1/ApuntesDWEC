# Vue.js 2
## Consumir REST API con vue-resource

Uso de vue-resource para consumir un API. Para el ejemplo
se está utilizando el API de JSONPlaceholder, que provee
algunos datos de prueba.

Se incluye el uso de:
- Iteración con la directiva v-for
- Modelos
- vue-resource
- Promesas
- Lifecycle hooks