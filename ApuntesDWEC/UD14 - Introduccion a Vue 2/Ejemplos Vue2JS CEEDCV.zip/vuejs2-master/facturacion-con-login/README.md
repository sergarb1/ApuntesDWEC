# Vue.js 2
## Ejemplo de formulario de facturación con login

Este es un ejemplo básico en el que se muestra cómo utilizar algunas de
las directivas de Vue.js.

Se incluyen
- Operaciones matemáticas básicas
- Iteración
- Borrado de productos
- Agregar nuevos productos dinámicamente
- Condicionales
- Búsqueda de elementos duplicados
- Computed properties

## Login
Los usuarios para realizar el login se encuentran en el código JavaScript, de
igual forma que la lista de productos. Para desbloquear el "sistema" utilice:

Usuario: admin
Contraseña: admin
