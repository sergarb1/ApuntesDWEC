const NoEncontrado = {
	template: `
		<div class="c-no-encontrado text-center">
			<h1>
				<span class="label label-danger">Ooops!</span>
			</h1>
			<p>La ruta a la que intenta ingresar no existe.</p>
		</div>
	`
};