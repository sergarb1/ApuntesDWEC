# Vue.js 2
## Svuetify

Esta "single-page application" está desarrollada con Vue.js,
vue-router y Bootstrap. No tiene alguna cosa fuera de lo común,
pero si combina muchas de las funcionalidades de Vue.js. Entre ellas:

- Watchers
- Routing
- B&uacute;squeda y filtrado de datos
- Modelos
- Lifecycle hooks
- M&eacute;todos
- Binding
- Eventos

Es posible agregar nuevos artistas dinámicamente.

DEMO: http://calirojas.com/demos/svuetify/