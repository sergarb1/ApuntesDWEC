# Vue.js 2
## Componente de tablas de multiplicar

Componente sencillo con la capacidad de instanciarse múltiples veces
con solo utilizar un tag personalizada. Se incluyen:

- Operaciones matemáticas básicas
- Iteración
- Condicionales
- Uso de templates
- Modelos
