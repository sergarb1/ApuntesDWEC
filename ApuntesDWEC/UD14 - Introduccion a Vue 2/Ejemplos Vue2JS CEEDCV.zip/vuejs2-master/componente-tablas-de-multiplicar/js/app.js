new Vue({
	// Indicamos el ID del Div que contiene la APP Vue
	el: '#app'
});