<!-- Fichero VUE en formato SFC (Single File Component) -->
<template>
  <div class="c-no-encontrado text-center">
			<h1>
				<span class="label label-danger">Error!</span>
			</h1>
			<p>La ruta indicada no existe.</p>
		</div>
</template>

<script>
</script>

<style>
</style>