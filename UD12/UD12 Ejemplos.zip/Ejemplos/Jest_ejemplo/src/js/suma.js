
// Funcion que realiza una simple suma
export function suma (a, b) {
  return a + b;
}
