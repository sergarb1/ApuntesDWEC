<!-- Aqui template, donde ira el HTML que Vue renderizara -->
<template>
  <div class="fixed-center text-center">
    <p>
      <img
        src="~assets/ceedcv.png"
      >
    </p>
    <p>Aplicación de ejemplo usando Quasar para el modulo DWEC impartido en el CEEDCV</p>
    <a href="http://ceedcv.org">Web del CEEDCV</a>

  </div>
</template>
<!-- Aqui script, donde irá el Javascript (métodos, funciones, etc) -->
<script>
export default {
  name: 'AcercaDe'
}
</script>
